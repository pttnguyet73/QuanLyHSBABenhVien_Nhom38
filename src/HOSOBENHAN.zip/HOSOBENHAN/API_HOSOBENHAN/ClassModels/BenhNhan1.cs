﻿namespace API_HOSOBENHAN.ClassModels
{
    public class BenhNhan1
    {
        public string Cccd { get; set; }
        public string TrieuChung { get; set; }
        public string Khoa { get; set; }

    }
}
