﻿namespace API_HOSOBENHAN.ClassModels
{
    public class PhieuChamSocMD
    {
        public string MaHSBA { get; set; }
        public DateTime Ngay { get; set; }
        public string DienBienBenh { get; set; }
        public string YLenh { get; set; }
        public string TenDieuDuong { get; set; }

    }
}
