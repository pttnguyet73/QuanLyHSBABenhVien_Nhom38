﻿namespace HOSOBENHAN.Models
{
    public class BNChuaCoHSBA
    {
        public string MaBN { get; set; }
        public string HoTen { get; set; }
        public string CCCD { get; set; }
        public DateTime NgayTao { get; set; }
    }
}
