﻿namespace HOSOBENHAN.Models
{
    public class BenhNhanTheoKhoa
    {
        public string  TenKhoa { get; set; }
        public int SoLuongBenhNhan {  get; set; }
    }
}
