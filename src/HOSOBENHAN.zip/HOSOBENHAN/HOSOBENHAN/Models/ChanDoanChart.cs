﻿namespace HOSOBENHAN.Models
{
    public class ChanDoanChart
    {
        public int SoLuongChuyenVien {  get; set; }
        public int SoLuongCapCuu { get; set; }
        public int SoLuongPhauThuat {  get; set; }
        public int SoLuongTaiKham {  get; set; }
    }
}
