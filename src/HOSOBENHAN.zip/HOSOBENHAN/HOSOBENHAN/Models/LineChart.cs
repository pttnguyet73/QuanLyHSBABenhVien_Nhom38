﻿namespace HOSOBENHAN.Models
{
    public class LineChart
    {
        public List<String> Labels { get; set; }
        public List<int> Series1 { get; set; }
        public List<int> Series2 { get; set; }
    }
}
