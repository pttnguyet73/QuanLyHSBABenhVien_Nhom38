﻿namespace HOSOBENHAN.Models
{
    public class PieChart
    {
        public int nam {  get; set; }
        public int thang { get; set; }
        public int daDieuTriXong { get; set; }
        
        public int chuaDieuTriXong {  set; get; }
    }
}
