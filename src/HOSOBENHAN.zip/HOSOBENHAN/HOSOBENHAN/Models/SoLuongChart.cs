﻿namespace HOSOBENHAN.Models
{
    public class SoLuongChart
    {
        public int BacSiTheoMa {  get; set; }
        public int BacSiChinhThuc { get; set; }
        public int NhanVienTheoMa { get; set; }
        public int YTaChinhThuc { get; set; }
        public int benhnhan {  get; set; }
        public int benhnhanmonth { get; set; }
        public int benhnhan2 { get; set; }
        public int benhnhan2month { get; set; }
    }
}
