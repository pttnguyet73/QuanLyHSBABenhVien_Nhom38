﻿namespace HOSOBENHAN.Models
{
    public class TaiKhamChart
    {
        public string MaHSBA {  get; set; }
        public string TenBenhNhan { get; set; }
        public DateTime tgTaiKham { get; set; }
        public string TrangThai { get; set; }
    }
}
