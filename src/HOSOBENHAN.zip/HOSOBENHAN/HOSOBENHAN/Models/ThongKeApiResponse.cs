﻿
    namespace HOSOBENHAN.Models
    {
        public class ThongKeApiResponse
        {
            public List<int> series1 { get; set; }
            public List<int> series2 { get; set; }
        }
    }

