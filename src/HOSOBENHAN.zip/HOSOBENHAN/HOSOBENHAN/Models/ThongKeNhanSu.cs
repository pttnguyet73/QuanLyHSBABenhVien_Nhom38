﻿namespace HOSOBENHAN.Models
{
    public class ThongKeNhanSu
    {
        public String TenKhoa { get; set; }
        public int SoLuongNhanVien { get; set; }
        public int SoLuongBacSi { get; set; }
    }
}
