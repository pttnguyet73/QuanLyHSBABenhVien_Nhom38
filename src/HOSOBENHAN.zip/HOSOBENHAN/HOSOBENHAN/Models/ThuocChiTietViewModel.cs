﻿namespace HOSOBENHAN.Models
{
    public class ThuocChiTietViewModel
    {
        public int STT { get; set; }
        public string TenThuoc { get; set; }
        public int SoLuong { get; set; }
        public string DonViTinh { get; set; }
        public string LieuDung { get; set; }
        public string GhiChu { get; set; }
    }
}
