﻿    namespace HOSOBENHAN.Models
    {
        public class TopKhoa
        {
            public string TenKhoa { get; set; }
            public int SoBenhNhan {  get; set; }
        }
    }
