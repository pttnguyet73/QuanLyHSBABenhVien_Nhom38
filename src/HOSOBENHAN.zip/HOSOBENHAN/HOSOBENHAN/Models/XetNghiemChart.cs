﻿namespace HOSOBENHAN.Models
{
    public class XetNghiemChart
    {
        public string LoaiXN {  get; set; }
        public int soBN { get; set; }
    }
}
